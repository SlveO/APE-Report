"""Bounded launch observation; never stops or signals background workers."""
import argparse
import shutil
import time
from pathlib import Path

from main80.common import inside, now, read_json, write_json
from main80.monitor import current_status


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--campaign', required=True)
    parser.add_argument('--seconds', type=int, default=60)
    args = parser.parse_args()
    if __import__('pathlib').Path(args.campaign).name != args.campaign:
        parser.error('campaign ID required')
    directory = inside('output/runs/' + args.campaign)
    if not 1 <= args.seconds <= 60:
        parser.error('--seconds must be within 1..60')
    started = time.monotonic()
    # Keep one second of process/recording margin inside the user-facing cap.
    end = started + max(0, args.seconds - 1)
    updates = []
    while time.monotonic() < end:
        if (directory / 'status.json').exists():
            status = current_status(directory)
            update = {k: status.get(k) for k in ('updated_at', 'state', 'stage', 'completed', 'planned', 'failed', 'historical_reused', 'elapsed_seconds', 'eta_range', 'monitor_url')}
            if not updates or update != updates[-1]:
                updates.append(update)
                print(update, flush=True)
            if status['state'] in ('BLOCKED', 'SUBMITTED', 'STALE'):
                break
        time.sleep(min(5, max(0, end - time.monotonic())))
    previous = directory / 'launch-observation.json'
    if previous.exists():
        archive_dir = directory / 'launch-observations'
        archive_dir.mkdir(exist_ok=True)
        sequence = 1
        while (archive_dir / f'{sequence:03d}.json').exists():
            sequence += 1
        shutil.copy2(previous, archive_dir / f'{sequence:03d}.json')
    write_json(directory / 'launch-observation.json', {'started_monotonic': started, 'ended_at': now(),
        'elapsed_seconds': time.monotonic() - started, 'hard_limit_seconds': args.seconds, 'updates': updates,
        'background_workers_stopped_by_observer': False, 'ETA_policy': 'unknown unless all pending method/length/cache strata have adequate formal observations'})


if __name__ == '__main__':
    main()
