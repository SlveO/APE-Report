"""Unified, resumable, no-deadline controller for FOLLOWUP2604.

The controller serializes GPU workers on physical GPU 0, freezes each rule
before any dependent test, and never uses elapsed time or ETA to stop, shrink,
or skip experiment work.  The only bounded clock is the separate foreground
launch observer.
"""
import argparse
import csv
import fcntl
import json
import math
import os
import shutil
import subprocess
import threading
import time
import traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from statistics import mean

from .campaign import PYTHON, _parent_death, bucket, launch_monitor, runtime_versions, start_browser
from .common import ROOT, append_json, identity, inside, now, read_json, read_records, write_json
from .followup_rules import (
    CORRECTED_RULE_VERSION, MAIN80_RULE_VERSION, NATURAL_METHODS, NATURAL_RULE_VERSION,
    confirmation_jobs, confirmation_summary, corrected_length_plan, corrected_rule,
    corrected_validation_outcomes, expand_confirmation,
    jsonl, natural_exploration_jobs, natural_validation_jobs, select_natural_candidates,
    freeze_natural_rule,
)


BASE = ROOT / 'output/runs'
LOCK = ROOT / '.runtime/followup2604.lock'
ACTIVE = ROOT / '.runtime/followup2604-active.json'
STAGES = (
    'A_CORRECTED_VALIDATION',
    'A_FREEZE_CORRECTED_RULE',
    'B_LENGTH_TRANSFER',
    'C1_NATURAL_EXPLORATION',
    'C1_SELECT_CANDIDATES',
    'C2_NATURAL_VALIDATION',
    'C2_FREEZE_NATURAL_RULE',
    'C3_INDEPENDENT_CONFIRMATION',
    'FINALIZE',
)
FORBIDDEN_TIME_KEYS = {
    'budget_seconds', 'wall_clock_limit', 'stage_time_limits', 'request_deadline',
    'deadline_epoch', 'timeout_seconds', 'worker_timeout', 'eta_shrink',
}
GENERATED = (
    'corrected-rule.json', 'corrected-length-plan.json',
    'natural-candidates.json', 'natural-validation-plan.json',
    'natural-rule.json', 'confirmation-plan.json',
)


def validate(config):
    """Check the experiment contract, never an agent's approval/identity fields."""
    fixed = {
        'protocol': 'ape-plan-exec/v1', 'task_id': 'FOLLOWUP2604',
        'plan_version': 'v3.3-adjusted', 'model': 'models/Llama-3.1-8B-Instruct',
        'physical_gpu': 0, 'dtype': 'bfloat16', 'batch_size': 1,
        'do_sample': False, 'num_beams': 1, 'seed': 42,
        'answer_upper_bound': 2604, 'launch_observation_seconds': 60,
        'main80_rule_version': MAIN80_RULE_VERSION,
        'corrected_rule_version': CORRECTED_RULE_VERSION,
        'natural_rule_version': NATURAL_RULE_VERSION,
    }
    for key, expected in fixed.items():
        if config.get(key) != expected:
            raise ValueError(f'FOLLOWUP2604 fixed protocol mismatch: {key}')
    forbidden = sorted(key for key in FORBIDDEN_TIME_KEYS if key in config)
    if forbidden:
        raise ValueError(f'FOLLOWUP2604 must omit all experiment deadline/timeout fields: {forbidden}')
    path_keys = (
        'config_source', 'model', 'corrected_data', 'historical_data', 'natural_data',
        'corrected_candidates', 'corrected_validation_jobs', 'corrected_validation_reuse',
        'historical_attempts', 'main80_rule',
    )
    for key in path_keys:
        inside(config[key])
    candidates = read_json(config['corrected_candidates'])
    if len(candidates.get('global', [])) != 2 or len(candidates.get('cells', {})) != 9:
        raise ValueError('corrected candidates lack the fixed parameter and nine cells')
    jobs = jsonl(config['corrected_validation_jobs'])
    reuse = jsonl(config['corrected_validation_reuse'])
    new_keys = {identity(job['key']) for job in jobs}
    reused_keys = {identity(item['key']) for item in reuse}
    if (len(jobs), len(new_keys), len(reuse), len(reused_keys)) != (462, 462, 377, 377) or new_keys & reused_keys:
        raise ValueError('A must contain 462 new and 377 disjoint frozen reuse keys')
    natural_ready = False
    natural_reason = None
    try:
        manifest = read_json(f'{config["natural_data"]}/frozen.json')
        if manifest.get('counts') != {'explore': 54, 'validation': 36,
                                      'confirmation': 150, 'total': 240}:
            raise ValueError('adjusted natural frozen counts mismatch')
        expected_quotas = {
            'explore': {'qasper/N1': 6, 'qasper/N2': 6, 'qasper/N3': 6,
                        'hotpotqa/N1': 18, 'musique/N1': 18},
            'validation': {'qasper/N1': 4, 'qasper/N2': 4, 'qasper/N3': 4,
                           'hotpotqa/N1': 12, 'musique/N1': 12},
            'confirmation': {'qasper/N1': 17, 'qasper/N2': 17, 'qasper/N3': 16,
                             'hotpotqa/N1': 50, 'musique/N1': 50},
        }
        if manifest.get('quotas') != expected_quotas:
            raise ValueError('adjusted natural N quotas mismatch')
        weights = read_json(f'{config["natural_data"]}/scoring-weights.json')
        if 'Qasper-only' not in weights.get('interpretation_boundary', ''):
            raise ValueError('natural weighting lacks the approved Qasper-only boundary')
        natural_ready = True
    except (OSError, ValueError, KeyError, TypeError) as exc:
        natural_reason = str(exc)
    return {
        'A_new_jobs': len(jobs), 'A_historical_reuse': len(reuse),
        'A_reuse_validation': 'at_result_reception_from_frozen_sources',
        'A_B_ready': True, 'C_ready': natural_ready, 'C_reason': natural_reason,
    }


INPUT_GROUPS = {
    'AB': ('corrected_data', 'historical_data', 'corrected_candidates',
           'corrected_validation_jobs', 'corrected_validation_reuse', 'historical_attempts'),
    'C': ('natural_data', 'main80_rule'),
}


def source_files(config):
    names = ('__init__', 'common', 'campaign', 'data', 'diagnostics', 'jobs', 'methods',
             'metrics', 'monitor', 'report', 'rules', 'worker', 'followup_rules', 'followup_campaign')
    files = [ROOT / f'APE/main80/{name}.py' for name in names]
    files += [
        ROOT / 'APE/ape/ape_llama.py', ROOT / 'APE/ape/__init__.py',
        ROOT / 'scripts/with_env.sh', ROOT / 'scripts/run_followup_campaign.sh',
        ROOT / 'scripts/observe_campaign.py',
    ]
    model = inside(config['model'])
    files.extend(model / name for name in (
        'config.json', 'generation_config.json', 'tokenizer.json',
        'tokenizer_config.json', 'special_tokens_map.json', 'model.safetensors.index.json'))
    return [inside(path) for path in files]


def _input_files(config, group):
    files = []
    for key in INPUT_GROUPS[group]:
        path = inside(config[key])
        if key in ('corrected_data', 'historical_data'):
            files.extend(path / name for name in ('frozen.json', 'development.json'))
        elif key == 'natural_data':
            manifest = read_json(path / 'frozen.json')
            files.append(path / 'frozen.json')
            files.extend(inside(path / name) for name in manifest['files'])
        else:
            files.append(path)
    return files


def _check_natural_snapshot(config):
    """At a new data freeze, check task IDs, complete token spans and isolation.

    Raw-source reconstruction belongs to the existing independent data freeze;
    neither startup status nor later stages repeat that corpus-wide audit.
    """
    from .data import question_key
    manifest = read_json(f'{config["natural_data"]}/frozen.json')
    rows = read_json(f'{config["natural_data"]}/natural.json')
    if len(rows) != 240 or len({row['sample_id'] for row in rows}) != 240:
        raise ValueError('natural sample IDs must be 240 unique frozen questions')
    counts = {split: Counter() for split in ('explore', 'validation', 'confirmation')}
    owners = {}
    for row in rows:
        split, dataset = row['split'], row['dataset']
        length, count = row['L'], row['natural_N']
        if (split not in counts or dataset not in ('qasper', 'hotpotqa', 'musique') or
                count not in (1, 2, 3) or (dataset != 'qasper' and count != 1) or
                len(row['document_tokens']) != length or count != math.ceil(length / 7500) or
                row['natural_chunk_intervals'] != [[i, min(i + 7500, length)] for i in range(0, length, 7500)] or
                row['max_new_tokens'] != (128 if dataset == 'qasper' else 32) or
                not row['answers'] or not row['document'] or not row['support_documents']):
            raise ValueError(f'invalid complete natural input: {row["sample_id"]}')
        counts[split][f'{dataset}/N{count}'] += 1
        identifiers = [('question', question_key(row['question'])), ('component', row['support_component'])]
        identifiers.extend(('support', document) for document in row['support_documents'])
        for identifier in identifiers:
            if identifier in owners and owners[identifier] != split:
                raise ValueError(f'natural split leakage: {identifier}')
            owners[identifier] = split
    if {split: dict(values) for split, values in counts.items()} != manifest['quotas']:
        raise ValueError('natural table quotas differ from the frozen manifest')
    for split in counts:
        if [row['sample_id'] for row in rows if row['split'] == split] != manifest['orders'][split]:
            raise ValueError(f'natural question order differs from frozen split {split}')
    weights = read_json(f'{config["natural_data"]}/scoring-weights.json')
    expected = {'qasper': 1/3, 'hotpotqa': 1/3, 'musique': 1/3}
    if (weights['global_candidate_and_fixed']['dataset_weights'] != expected or
            weights['global_candidate_and_fixed']['within_dataset'] != {
                'qasper': {'N1': 1/3, 'N2': 1/3, 'N3': 1/3},
                'hotpotqa': {'N1': 1.0}, 'musique': {'N1': 1.0}} or
            weights['conditional_candidates'] != {'N1': {'datasets': expected},
                'N2': {'datasets': {'qasper': 1.0}}, 'N3': {'datasets': {'qasper': 1.0}}}):
        raise ValueError('natural selection weights differ from the fixed research design')
    return {'questions': 240, 'quotas': 'matched', 'token_spans': 'complete', 'split_isolation': 'passed'}


def _freeze_inputs(directory, config, group, version, legacy=False):
    source_config = {key: config[key] for key in INPUT_GROUPS[group]}
    record = {'version': version, 'at': now(), 'source_config': source_config}
    target_root = directory / 'snapshot' if legacy else directory / f'snapshot/input-versions/{group}-{version:03d}'
    try:
        # Existing launches already own full frozen copies. Never re-read their
        # original datasets or historical ledgers merely to adopt that record.
        location = dict(config)
        if legacy:
            location.update({key: str(target_root / inside(value).relative_to(ROOT))
                             for key, value in source_config.items()})
        files = _input_files(location, group)
        copied = {}
        for path in files:
            if legacy:
                saved = path
                source = ROOT / path.relative_to(target_root)
                if not saved.is_file():
                    raise FileNotFoundError(saved)
            else:
                source = path
                saved = inside(target_root / source.relative_to(ROOT))
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, saved)
            copied[str(source)] = str(saved)
        record.update(available=True, files=copied,
                      bound_config={key: str(target_root / inside(value).relative_to(ROOT))
                                    for key, value in source_config.items()})
        if group == 'C' and not legacy:
            record['data_checks'] = _check_natural_snapshot({**config, **record['bound_config']})
    except (OSError, KeyError, ValueError, TypeError) as exc:
        if group == 'AB':
            raise
        record.update(available=False, reason=str(exc), files={}, bound_config=source_config)
    return record


def _started_groups(directory):
    state = read_json(directory / 'state.json') if (directory / 'state.json').exists() else {}
    stages = set(state.get('started_stages', [])) | set(state.get('completed_stages', []))
    events, _ = read_records(directory / 'events.jsonl')
    stages.update(event.get('stage') for event in events if event.get('event') == 'worker_started')
    records, _ = read_records(directory / 'attempts.jsonl')
    stages.update({'validation': 'A_CORRECTED_VALIDATION', 'corrected_length_transfer': 'B_LENGTH_TRANSFER',
                   'natural_exploration': 'C1_NATURAL_EXPLORATION', 'natural_validation': 'C2_NATURAL_VALIDATION',
                   'independent_confirmation': 'C3_INDEPENDENT_CONFIRMATION'}.get(record.get('key', {}).get('stage'))
                  for record in records)
    return {group for group in INPUT_GROUPS if any(stage and stage.startswith(group if group == 'C' else ('A', 'B'))
                                                  for stage in stages)}


def snapshot(directory, config, gate=None, resume=False, register_inputs=False):
    """Pin inputs by dependency; record maintained code separately on recovery."""
    registry_path = directory / 'input-versions.json'
    if registry_path.exists():
        registry = read_json(registry_path)
    else:
        registry = {'protocol': 'ape-followup-input-versions-v1', 'groups': {}}
        original = read_json(directory / 'config.json')
        legacy = (directory / 'source-files.json').exists()
        for group in INPUT_GROUPS:
            registry['groups'][group] = [_freeze_inputs(directory, original, group, 1, legacy)]
    started = _started_groups(directory) if resume else set()
    for group, versions in registry['groups'].items():
        current = versions[-1]
        if not register_inputs:
            continue
        spec = {key: config[key] for key in INPUT_GROUPS[group]}
        same = spec == current['source_config'] and current['available']
        if same:
            files = _input_files(config, group)
            same = set(map(str, files)) == set(current['files']) and all(
                path.read_bytes() == inside(current['files'][str(path)]).read_bytes() for path in files)
        if not same:
            if group in started:
                raise ValueError(f'cannot change inputs of started dependency group {group}')
            versions.append(_freeze_inputs(directory, config, group, current['version'] + 1))
    bound = dict(config)
    for versions in registry['groups'].values():
        bound.update(versions[-1]['bound_config'])
    gate = validate(bound)
    if not registry['groups']['C'][-1]['available']:
        gate.update(C_ready=False, C_reason=registry['groups']['C'][-1]['reason'])
    for name in GENERATED:
        artifact = directory / name
        sealed = directory / 'snapshot/generated' / name
        if sealed.exists() and not artifact.exists():
            write_json(artifact, read_json(sealed))
            append_json(directory / 'events.jsonl', {'event': 'generated_artifact_restored', 'at': now(),
                                                    'name': name, 'generation_repeated': False})
        if artifact.exists() != sealed.exists() or (artifact.exists() and artifact.read_bytes() != sealed.read_bytes()):
            raise ValueError(f'frozen generated artifact changed: {name}')
    versions_path = directory / 'code-versions.json'
    versions = read_json(versions_path) if versions_path.exists() else []
    files = source_files(config)
    same_code = bool(versions) and set(map(str, files)) == set(versions[-1]['files']) and all(
        path.read_bytes() == inside(versions[-1]['files'][str(path)]).read_bytes() for path in files)
    if not same_code:
        version = len(versions) + 1
        copied = {}
        for path in files:
            saved = inside(directory / f'snapshot/code-versions/{version:03d}' / path.relative_to(ROOT))
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, saved)
            copied[str(path)] = str(saved)
        versions.append({'version': version, 'at': now(), 'files': copied,
                         'observed_HEAD_text': (ROOT / 'APE/.git/HEAD').read_text().strip(),
                         'legacy_snapshot_preserved': True, 'identity': 'full copies and direct byte comparisons; no digest'})
        write_json(versions_path, versions)
    write_json(registry_path, registry)
    write_json(directory / 'requested-config.json', config)
    write_json(directory / 'runtime.json', {'config': bound, 'gate': gate,
                                          'input_versions': {group: entries[-1]['version'] for group, entries in registry['groups'].items()},
                                          'code_version': versions[-1]['version']})
    write_json(directory / 'environment.json', {'python': PYTHON, 'packages': runtime_versions(),
        'physical_gpu': 0, 'dtype': 'bfloat16', 'batch_size': 1, 'greedy': True, 'seed': 42,
        'model_path': str(inside(config['model'])), 'overlays': ['.overlays/core-tf44', '.overlays/main80-scoring'],
        'local_files_only': True, 'trust_remote_code': False, 'external_dependencies_modified': False})
    return bound, gate


def seal_generated(directory, name, content):
    artifact = directory / name
    sealed = directory / 'snapshot/generated' / name
    sealed.parent.mkdir(parents=True, exist_ok=True)
    if sealed.exists():
        existing = read_json(sealed)
        comparable = {key: value for key, value in existing.items() if key != 'frozen_at'}
        if comparable != content:
            raise ValueError(f'cannot replace frozen generated artifact: {name}')
    else:
        if artifact.exists():
            raise ValueError(f'cannot use an unsealed generated artifact: {name}')
        write_json(sealed, {**content, 'frozen_at': now()})
    if artifact.exists():
        if artifact.read_bytes() != sealed.read_bytes():
            raise ValueError(f'generated artifact changed: {name}')
    else:
        write_json(artifact, read_json(sealed))


def _write_jsonl(path, rows):
    path = inside(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        for row in rows:
            stream.write(identity(row) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def ensure_reuse_rows(directory, rows, phase):
    path = directory / 'reuse.jsonl'
    existing, malformed = read_records(path)
    if malformed:
        raise ValueError(f'malformed reuse ledger: {malformed}')
    existing_phase = [row for row in existing if row.get('phase') == phase]
    if existing_phase:
        if [identity(row) for row in existing_phase] != [identity(row) for row in rows]:
            raise ValueError(f'frozen reuse evidence changed for {phase}')
        return
    for row in rows:
        append_json(path, row)


@lru_cache(maxsize=None)
def _frozen_jobs(path, json_lines=False):
    return jsonl(path) if json_lines else read_json(path)['jobs']


@lru_cache(maxsize=None)
def _natural_jobs(path):
    return natural_exploration_jobs({'natural_data': path})


class ProgressLedger:
    """Incremental controller view of the append-only result ledger."""
    def __init__(self, path):
        self.path = path
        self.offset = 0
        self.records = []
        self.success = {}
        self.incomplete = []
        self.errors = []

    def refresh(self):
        if not self.path.exists():
            return self
        with self.path.open('rb') as stream:
            stream.seek(self.offset)
            while True:
                start = stream.tell()
                line = stream.readline()
                if not line or not line.endswith(b'\n'):
                    break
                self.offset = stream.tell()
                try:
                    record = json.loads(line)
                    signature = identity(record['key'])
                    self.records.append(record)
                    if record.get('status') == 'success':
                        if signature in self.success:
                            self.errors.append('duplicate successful result')
                        if not record.get('answer', '').strip() or not record.get('output_token_ids'):
                            self.errors.append('invalid successful output')
                        else:
                            self.success[signature] = record
                except (ValueError, KeyError, TypeError, UnicodeDecodeError) as exc:
                    self.incomplete.append({'byte_offset': start, 'error': str(exc)})
        return self

    def done(self, key):
        return identity(key) in self.success

    def outcome(self, key):
        return self.success.get(identity(key))


_PROGRESS = {}


def _ledger(directory):
    name = str(directory)
    if name not in _PROGRESS:
        _PROGRESS[name] = ProgressLedger(directory / 'attempts.jsonl')
    return _PROGRESS[name].refresh()


def _plan_jobs(directory, config, gate):
    plans = {'A': _frozen_jobs(config['corrected_validation_jobs'], True)}
    if (directory / 'corrected-length-plan.json').exists():
        plans['B'] = _frozen_jobs(str(directory / 'corrected-length-plan.json'))
    if gate['C_ready']:
        plans['C1'] = _natural_jobs(config['natural_data'])
        if (directory / 'natural-validation-plan.json').exists():
            plans['C2'] = _frozen_jobs(str(directory / 'natural-validation-plan.json'))
        if (directory / 'confirmation-plan.json').exists():
            plans['C3'] = _frozen_jobs(str(directory / 'confirmation-plan.json'))
    return plans


def _current_jobs(directory, config, gate, stage):
    plans = _plan_jobs(directory, config, gate)
    return {
        'A_CORRECTED_VALIDATION': plans.get('A', []),
        'B_LENGTH_TRANSFER': plans.get('B', []),
        'C1_NATURAL_EXPLORATION': plans.get('C1', []),
        'C2_NATURAL_VALIDATION': plans.get('C2', []),
        'C3_INDEPENDENT_CONFIRMATION': plans.get('C3', []),
    }.get(stage, [])


def _rates(records):
    values = defaultdict(list)
    for record in records:
        if record.get('status') != 'success' or not record.get('total_seconds'):
            continue
        labels = [label for label in record.get('logical_labels', []) if label in NATURAL_METHODS]
        methods = labels or [record.get('method', 'unknown')]
        for method in methods:
            key = (method, bucket(record.get('L') or 1), record.get('cache_mode', 'cold'))
            values[key].append(float(record['total_seconds']))
    return [
        {'method': key[0], 'length_bucket': key[1], 'cache_mode': key[2],
         'count': len(samples), 'mean': mean(samples),
         'low': min(samples), 'high': max(samples)}
        for key, samples in sorted(values.items())
    ]


def _stage_eta(jobs, ledger, records):
    pending = [job for job in jobs if not ledger.done(job['key'])]
    if not pending:
        return (0.0, 0.0)
    samples = defaultdict(list)
    for record in records:
        if record.get('status') == 'success' and record.get('total_seconds'):
            key = (record.get('engine_method', record.get('method')),
                   bucket(record.get('L') or 1), record.get('cache_mode', 'cold'))
            samples[key].append(float(record['total_seconds']))
    low = high = 0.0
    for job in pending:
        key = (job.get('engine_method', job['method']),
               bucket(job['key'].get('L') or 1), job['cache'])
        observed = samples.get(key, [])
        if len(observed) < 3:
            return None
        low += min(observed)
        high += max(observed)
    return low, high


def update_status(directory, state, config, gate):
    ledger = _ledger(directory)
    plans = _plan_jobs(directory, config, gate)
    exact = all(name in plans for name in (('A', 'B', 'C1', 'C2', 'C3') if gate['C_ready'] else ('A', 'B')))
    planned = sum(len(jobs) for jobs in plans.values()) if exact else config['answer_upper_bound']
    b_reuse = (read_json(directory / 'corrected-length-plan.json').get('historical_reuse', 0)
               if (directory / 'corrected-length-plan.json').exists() else 0)
    historical_reused = 377 + b_reuse
    parameter_reuse = 0
    if 'C2' in plans:
        parameter_reuse += sum(max(0, len(job.get('logical_labels', [])) - 1) for job in plans['C2'])
    if 'C3' in plans:
        parameter_reuse += sum(max(0, len(job.get('logical_labels', [])) - 1) for job in plans['C3'])
    records = ledger.records
    successful_keys = {identity(record['key']) for record in records if record.get('status') == 'success'}
    all_known = [job for jobs in plans.values() for job in jobs]
    completed = sum(identity(job['key']) in successful_keys for job in all_known)
    failures = [record for record in records if record.get('status') != 'success']
    current = _current_jobs(directory, config, gate, state.get('stage'))
    eta = _stage_eta(current, ledger, records) if current else None
    stamp = time.time()
    eta_range = ([datetime.fromtimestamp(stamp + value, timezone.utc).isoformat() for value in eta]
                 if eta is not None else None)
    notices = state.get('notices', [])[-10:]
    heartbeat = read_json(directory / 'worker-state.json') if (directory / 'worker-state.json').exists() else {}
    status = {
        'campaign': directory.name, 'state': state['state'], 'stage': state.get('stage'),
        'updated_at': now(), 'completed': completed, 'planned': planned,
        'planned_is_exact': exact, 'planned_upper_bound': config['answer_upper_bound'],
        'failed': len(failures), 'processed_including_failed': len(records),
        'historical_reused': historical_reused,
        'parameter_deduplicated_logical_labels': parameter_reuse,
        'elapsed_seconds': max(0, stamp - state['started_epoch']),
        'remaining_seconds': None, 'budget_seconds': None, 'no_wall_clock_limit': True,
        'eta_range': eta_range,
        'eta_scope': 'current_GPU_stage_only' if eta is not None else None,
        'eta_label': ('当前GPU阶段已观测分层估计；未作为停止或缩样条件'
                      if eta is not None else '暂不能可靠估计'),
        'rates': _rates(records), 'current_job': heartbeat.get('job'),
        'notices': notices, 'monitor_url': state.get('monitor_url'),
        'completed_stages': state.get('completed_stages', []),
        'C_data_ready': gate['C_ready'], 'C_data_reason': gate['C_reason'],
        'stage_completed': sum(ledger.done(job['key']) for job in current),
        'stage_planned': len(current), 'input_versions': state.get('input_versions'),
        'code_version': state.get('code_version'),
    }
    write_json(directory / 'status.json', status)
    write_json(directory / 'state.json', state)
    incomplete = [job['key'] for job in all_known if not ledger.done(job['key'])]
    write_json(directory / 'incomplete.json', {
        'at': now(), 'known_pending_count': len(incomplete), 'keys': incomplete,
        'future_plan_not_yet_frozen': not exact,
        'blocked_stage': state.get('blocked_stage'), 'blocked_reason': state.get('blocked_reason'),
    })
    write_json(directory / 'summary.json', {
        'at': now(), 'status': state['state'], 'stage': state.get('stage'),
        'new_successes': completed, 'new_planned': planned, 'planned_is_exact': exact,
        'historical_reused': historical_reused, 'failed_attempts': len(failures),
        'completed_stages': state.get('completed_stages', []),
        'requires_PLANNER_review': True,
    })
    return status


def _run_jobs(directory, state, config, gate, stage, jobs, data, rule=None):
    ledger = _ledger(directory)
    if ledger.errors:
        raise ValueError('; '.join(ledger.errors))
    if stage not in state.setdefault('started_stages', []):
        state['started_stages'].append(stage)
        write_json(directory / 'state.json', state)
    groups = []
    for engine_method in dict.fromkeys(job.get('engine_method', job['method']) for job in jobs):
        groups.append((engine_method, [job for job in jobs
                                      if job.get('engine_method', job['method']) == engine_method]))
    for engine_method, group in groups:
        ledger = _ledger(directory)
        terminal_sample_errors = {identity(record['key']) for record in ledger.records
                                  if record.get('status') == 'sample_error'}
        pending = [job for job in group if not ledger.done(job['key'])
                   and identity(job['key']) not in terminal_sample_errors]
        if not pending:
            continue
        serial = len(list((directory / 'workers').glob('*.bundle.json'))) if (directory / 'workers').exists() else 0
        safe_method = engine_method.replace('/', '_')
        stem = directory / 'workers' / f'{serial:03d}-{stage}-{safe_method}'
        stem.parent.mkdir(parents=True, exist_ok=True)
        logical = pending[0]['method'] if all(job['method'] == pending[0]['method'] for job in pending) else 'mixed'
        bundle = {
            'model': config['model'], 'data': data, 'method': logical,
            'engine_method': engine_method, 'jobs': pending,
            'ledger': str(directory / 'attempts.jsonl'),
            'events': str(directory / 'events.jsonl'),
            'heartbeat': str(directory / 'worker-state.json'),
            'attention': str(directory / 'attention-unused.jsonl'),
            'rule': str(rule) if rule else None,
            'strict_pairing': True, 'stop_on_sample_error': True,
            'input_versions': state.get('input_versions'), 'code_version': state.get('code_version'),
            'answer_upper_bound': config['answer_upper_bound'],
        }
        if any(key in bundle for key in ('deadline_epoch', 'timeout_seconds')):
            raise AssertionError('FOLLOWUP2604 worker bundle acquired a forbidden deadline')
        bundle_path = str(stem) + '.bundle.json'
        write_json(bundle_path, bundle)
        command = [PYTHON, '-B', '-u', '-m', 'main80.worker', '--bundle', bundle_path]
        append_json(directory / 'events.jsonl', {
            'event': 'worker_started', 'at': now(), 'stage': stage,
            'method': logical, 'engine_method': engine_method,
            'jobs': len(pending), 'command': command, 'cwd': str(ROOT),
            'elapsed_time_control': False, 'timeout_kill': False,
        })
        with Path(str(stem) + '.stdout').open('ab') as stdout, Path(str(stem) + '.stderr').open('ab') as stderr:
            worker = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr,
                                      start_new_session=True, preexec_fn=_parent_death)
        write_json(directory / 'worker.json', {
            'pid': worker.pid, 'command': command, 'cwd': str(ROOT),
            'started_at': now(), 'stage': stage, 'elapsed_time_control': False,
        })
        try:
            while worker.poll() is None:
                try:
                    worker.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
                update_status(directory, state, config, gate)
        except BaseException:
            # Only a correctness/controller exception signals our own worker.
            # There is no elapsed-time watchdog or timeout kill escalation.
            if worker.poll() is None:
                worker.terminate()
                worker.wait()
            raise
        append_json(directory / 'events.jsonl', {
            'event': 'worker_ended', 'at': now(), 'stage': stage,
            'method': logical, 'engine_method': engine_method,
            'exit_code': worker.returncode, 'stopped_for_elapsed_time': False,
        })
        if worker.returncode:
            raise RuntimeError(f'worker stopped: {stage}/{engine_method}, exit {worker.returncode}')
    ledger = _ledger(directory)
    if ledger.errors:
        raise ValueError('; '.join(ledger.errors))
    missing = [job['key'] for job in jobs if not ledger.done(job['key'])]
    if missing:
        raise RuntimeError(f'{stage} has failed or incomplete answers: {len(missing)}')


def _attempt_records(directory, stage, jobs):
    ledger = _ledger(directory)
    results = []
    for job in jobs:
        outcome = ledger.outcome(job['key'])
        if (outcome is None or outcome.get('status') != 'success' or
                identity(outcome.get('key')) != identity(job['key']) or
                outcome.get('sample_id') != job['key']['sample_id']):
            raise ValueError(f'{stage} result is missing: {job["key"]}')
        results.append(outcome)
    return results


def _mark_stage(directory, state, config, gate, stage):
    if stage not in state['completed_stages']:
        state['completed_stages'].append(stage)
    append_json(directory / 'events.jsonl', {
        'event': 'stage_submitted', 'at': now(), 'stage': stage,
        'machine_checks_passed': True, 'PLANNER_acceptance_pending': True,
    })
    update_status(directory, state, config, gate)


def _length_results(directory, plan):
    attempts = _ledger(directory)
    results = []
    for job in plan['jobs']:
        record = attempts.outcome(job['key'])
        if record is None or record.get('status') != 'success':
            raise ValueError(f'missing new length-transfer result: {job["key"]}')
        results.append({**record, 'answer_origin': 'new_followup_generation'})
    results.extend({**item, 'status': 'success', 'answer_origin': 'historical_exact_reuse'}
                   for item in plan['reuse'])
    if len(results) != 120 or len({identity(item['key']) for item in results}) != 120:
        raise ValueError('corrected length transfer is not 120 complete unique logical outcomes')
    results.sort(key=lambda item: identity(item['key']))
    return results


def _export_pc_package(directory, config, confirmation, confirmation_report):
    package = directory / 'pc-analysis'
    package.mkdir(parents=True, exist_ok=True)
    sources = {
        'corrected-validation-results.jsonl': directory / 'corrected-validation-results.jsonl',
        'corrected-length-results.jsonl': directory / 'corrected-length-results.jsonl',
        'natural-exploration-results.jsonl': directory / 'natural-exploration-results.jsonl',
        'natural-validation-results.jsonl': directory / 'natural-validation-results.jsonl',
        'confirmation-results.jsonl': directory / 'confirmation-results.jsonl',
        'reuse.jsonl': directory / 'reuse.jsonl',
        'corrected-rule.json': directory / 'corrected-rule.json',
        'natural-candidates.json': directory / 'natural-candidates.json',
        'natural-rule.json': directory / 'natural-rule.json',
        'config.json': directory / 'config.json',
        'requested-config.json': directory / 'requested-config.json',
        'input-versions.json': directory / 'input-versions.json',
        'code-versions.json': directory / 'code-versions.json',
        'environment.json': directory / 'environment.json',
        'sampling.json': directory / 'sampling.json',
        'attempts.jsonl': directory / 'attempts.jsonl',
        'events.jsonl': directory / 'events.jsonl',
        'corrected-length-plan.json': directory / 'corrected-length-plan.json',
        'natural-validation-plan.json': directory / 'natural-validation-plan.json',
        'confirmation-plan.json': directory / 'confirmation-plan.json',
        'natural-splits.json': inside(config['natural_data']) / 'frozen.json',
        'scoring-weights.json': inside(config['natural_data']) / 'scoring-weights.json',
        'split-overlap.json': inside(config['natural_data']) / 'split-overlap.json',
    }
    for name, source in sources.items():
        if source.exists():
            shutil.copyfile(source, package / name)
    csv_path = package / 'confirmation-results.csv'
    fields = ('sample_id', 'dataset', 'natural_N', 'L', 'method', 'score', 'answer',
              'T', 'S', 'parameter_reuse')
    with csv_path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in confirmation:
            writer.writerow({field: row.get(field) for field in fields})
    write_json(package / 'confirmation-summary.json', confirmation_report)
    (package / 'README.md').write_text(
        '# FOLLOWUP2604 PC analysis\n\n'
        'Read confirmation-results.csv or JSONL using Python standard libraries. '
        'Seven logical methods share 150 independent questions; exact APE parameters are generated once. '
        'The primary metric is the equal mean of three dataset F1 means. '
        'Qasper N1/N2/N3 are reported separately; multi-block evidence is Qasper-only. '
        'Candidate selection uses exploration and validation only.\n\n'
        'Full input/code copies and per-worker commands remain in the campaign snapshot and workers directories; '
        'input-versions.json and code-versions.json list their exact paths. '
        'All raw attempts and reuse reasons are included. Status is SUBMITTED pending PLANNER acceptance.\n')
    write_json(package / 'MANIFEST.json', {
        'protocol': 'ape-followup-pc-analysis-v1', 'created_at': now(),
        'files': sorted(path.name for path in package.iterdir() if path.is_file()),
        'row_counts': {'confirmation_logical_methods': len(confirmation)},
        'rule_versions': {
            'historical_MAIN80': MAIN80_RULE_VERSION,
            'corrected_length_transfer': CORRECTED_RULE_VERSION,
            'natural_chunks': NATURAL_RULE_VERSION,
        },
        'scoring': 'official LongBench QA F1; frozen per-question scores included',
        'interpretation_boundary': 'multi-block results are Qasper-only; cross-dataset differences are not block-count effects',
        'identity': 'full files and row IDs/counts; no digest or checksum computed',
    })


def _finalize(directory, state, config, gate):
    # These tables passed their checks at result reception. Final export does
    # not rescan/re-score the historical answers or re-run earlier audits.
    a_results = jsonl(directory / 'corrected-validation-results.jsonl')
    if len(a_results) != 839:
        raise ValueError('validated A result table is incomplete')
    length_plan = read_json(directory / 'corrected-length-plan.json')
    c1_jobs = _natural_jobs(config['natural_data'])
    c2_jobs = read_json(directory / 'natural-validation-plan.json')['jobs']
    c3_jobs = read_json(directory / 'confirmation-plan.json')['jobs']
    c3_records = _attempt_records(directory, 'independent_confirmation', c3_jobs)
    expanded = expand_confirmation(c3_records, c3_jobs)
    _write_jsonl(directory / 'confirmation-results.jsonl', expanded)
    report = confirmation_summary(expanded)
    write_json(directory / 'confirmation-summary.json', report)
    _export_pc_package(directory, config, expanded, report)
    ledger = _ledger(directory)
    failures = [record for record in ledger.records if record.get('status') != 'success']
    stage_counts = {
        'A_corrected_validation': {'new': 462, 'historical_reuse': 377, 'logical_outcomes': 839},
        'B_length_transfer': {'new': length_plan['new_jobs'],
                              'historical_reuse': length_plan['historical_reuse'],
                              'logical_outcomes': 120},
        'C1_natural_exploration': {'new': len(c1_jobs), 'logical_outcomes': 864},
        'C2_natural_validation': {
            'new': len(c2_jobs),
            'deduplicated_labels': sum(max(0, len(job['logical_labels']) - 1) for job in c2_jobs),
        },
        'C3_independent_confirmation': {
            'new': len(c3_jobs), 'logical_method_outcomes': 1050,
            'deduplicated_labels': 1050 - len(c3_jobs),
        },
    }
    write_json(directory / 'final-summary.json', {
        'protocol': 'ape-followup-final-summary-v1', 'at': now(),
        'task_status': 'SUBMITTED', 'stage_counts': stage_counts,
        'new_answer_generations': sum(item.get('new', 0) for item in stage_counts.values()),
        'new_answer_upper_bound': 2604,
        'historical_answer_reuse': 377 + length_plan['historical_reuse'],
        'failed_attempts_preserved': len(failures),
        'rule_versions': [MAIN80_RULE_VERSION, CORRECTED_RULE_VERSION, NATURAL_RULE_VERSION],
        'confirmation': report,
        'requires_PLANNER_review': True, 'self_acceptance': False,
    })


def _monitor_loop(directory, state):
    """Browser communication is observational and cannot stop the experiment."""
    url = None
    browser_started = None
    last_error = None
    while state['state'] == 'RUNNING':
        try:
            if url is None:
                url = launch_monitor(directory)
                state['monitor_url'] = url
            if browser_started is None:
                since = now()
                start_browser(directory, url)
                browser_started = since
            receipts, _ = read_records(directory / 'browser-seen.jsonl')
            if any(receipt.get('rendered') is True and receipt.get('at', '') >= browser_started and
                   any(name in receipt.get('user_agent', '') for name in ('Chrome/', 'Firefox/'))
                   for receipt in receipts):
                append_json(directory / 'events.jsonl', {'event': 'browser_confirmed', 'at': now(),
                                                        'url': url, 'refresh_seconds': 5})
                return
        except (OSError, ValueError, RuntimeError) as exc:
            if str(exc) != last_error:
                append_json(directory / 'events.jsonl', {'event': 'monitor_communication_pending',
                    'at': now(), 'error': str(exc), 'experiment_stopped': False})
                last_error = str(exc)
            if url is None:
                browser_started = None
        time.sleep(5)


def control(directory, lock_fd):
    runtime = read_json(directory / 'runtime.json')
    config, gate = runtime['config'], runtime['gate']
    state = read_json(directory / 'state.json')
    state['state'] = 'RUNNING'
    state['controller_pid'] = os.getpid()
    state.pop('blocked_stage', None)
    state.pop('blocked_reason', None)
    state['input_versions'] = runtime['input_versions']
    state['code_version'] = runtime['code_version']
    state['last_controller_started_at'] = now()
    try:
        update_status(directory, state, config, gate)
        threading.Thread(target=_monitor_loop, args=(directory, state), daemon=True).start()
        for stage in STAGES:
            if stage in state['completed_stages']:
                continue
            state['stage'] = stage
            update_status(directory, state, config, gate)
            if stage == 'A_CORRECTED_VALIDATION':
                jobs = _frozen_jobs(config['corrected_validation_jobs'], True)
                _run_jobs(directory, state, config, gate, stage, jobs,
                          config['corrected_data'])
            elif stage == 'A_FREEZE_CORRECTED_RULE':
                outcomes, reuse_rows = corrected_validation_outcomes(directory, config)
                _write_jsonl(directory / 'corrected-validation-results.jsonl', outcomes)
                ensure_reuse_rows(directory, reuse_rows, 'corrected_validation')
                rule = corrected_rule(outcomes, read_json(config['corrected_candidates']))
                seal_generated(directory, 'corrected-rule.json', rule)
            elif stage == 'B_LENGTH_TRANSFER':
                rule = read_json(directory / 'corrected-rule.json')
                if rule.get('version_id') != CORRECTED_RULE_VERSION:
                    raise ValueError('corrected rule was not frozen before B')
                if not (directory / 'corrected-length-plan.json').exists():
                    seal_generated(directory, 'corrected-length-plan.json',
                                   corrected_length_plan(config, rule))
                plan = read_json(directory / 'corrected-length-plan.json')
                ensure_reuse_rows(directory, plan['reuse'], 'corrected_length_transfer')
                _run_jobs(directory, state, config, gate, stage, plan['jobs'],
                          config['corrected_data'], directory / 'corrected-rule.json')
                _write_jsonl(directory / 'corrected-length-results.jsonl',
                             _length_results(directory, plan))
            elif stage == 'C1_NATURAL_EXPLORATION':
                if not gate['C_ready']:
                    state['state'] = 'BLOCKED'
                    state['blocked_stage'] = stage
                    state['blocked_reason'] = gate['C_reason'] or 'adjusted natural data is not ready'
                    append_json(directory / 'events.jsonl', {
                        'event': 'data_gate_blocked', 'at': now(), 'stage': stage,
                        'A_B_preserved': True, 'reason': state['blocked_reason'],
                    })
                    break
                jobs = _natural_jobs(config['natural_data'])
                _run_jobs(directory, state, config, gate, stage, jobs, config['natural_data'])
            elif stage == 'C1_SELECT_CANDIDATES':
                jobs = _natural_jobs(config['natural_data'])
                records = _attempt_records(directory, 'natural_exploration', jobs)
                candidates = select_natural_candidates(records, jobs)
                seal_generated(directory, 'natural-candidates.json', candidates)
                _write_jsonl(directory / 'natural-exploration-results.jsonl', records)
            elif stage == 'C2_NATURAL_VALIDATION':
                candidates = read_json(directory / 'natural-candidates.json')
                if candidates.get('status') != 'SELECTED_FOR_VALIDATION':
                    raise ValueError('natural candidates were not frozen before C2')
                if not (directory / 'natural-validation-plan.json').exists():
                    jobs = natural_validation_jobs(config, candidates)
                    seal_generated(directory, 'natural-validation-plan.json', {
                        'protocol': 'ape-followup-natural-validation-plan-v2',
                        'candidate_version': NATURAL_RULE_VERSION,
                        'questions': 36, 'physical_jobs': len(jobs), 'jobs': jobs,
                        'same_parameter_generated_once': True,
                    })
                jobs = read_json(directory / 'natural-validation-plan.json')['jobs']
                _run_jobs(directory, state, config, gate, stage, jobs, config['natural_data'])
            elif stage == 'C2_FREEZE_NATURAL_RULE':
                jobs = read_json(directory / 'natural-validation-plan.json')['jobs']
                records = _attempt_records(directory, 'natural_validation', jobs)
                rule = freeze_natural_rule(records, jobs, read_json(directory / 'natural-candidates.json'))
                seal_generated(directory, 'natural-rule.json', rule)
                _write_jsonl(directory / 'natural-validation-results.jsonl', records)
            elif stage == 'C3_INDEPENDENT_CONFIRMATION':
                rule = read_json(directory / 'natural-rule.json')
                if rule.get('version_id') != NATURAL_RULE_VERSION:
                    raise ValueError('natural rule was not frozen before C3')
                if not (directory / 'confirmation-plan.json').exists():
                    jobs = confirmation_jobs(config, rule)
                    seal_generated(directory, 'confirmation-plan.json', {
                        'protocol': 'ape-followup-confirmation-plan-v2',
                        'questions': 150, 'logical_methods_per_question': 7,
                        'logical_outcomes': 1050, 'physical_jobs': len(jobs),
                        'same_resolved_APE_parameter_generated_once': True,
                        'jobs': jobs,
                    })
                jobs = read_json(directory / 'confirmation-plan.json')['jobs']
                _run_jobs(directory, state, config, gate, stage, jobs, config['natural_data'])
            elif stage == 'FINALIZE':
                _finalize(directory, state, config, gate)
            _mark_stage(directory, state, config, gate, stage)
        if state['state'] == 'RUNNING' and all(stage in state['completed_stages'] for stage in STAGES):
            state['state'] = 'SUBMITTED'
            state['stage'] = 'SUBMITTED_FOR_PLANNER_REVIEW'
            append_json(directory / 'events.jsonl', {
                'event': 'campaign_submitted', 'at': now(),
                'requires_PLANNER_review': True, 'self_acceptance': False,
            })
    except BaseException as exc:
        state['state'] = 'BLOCKED'
        state['blocked_stage'] = state.get('stage')
        state['blocked_reason'] = str(exc)
        append_json(directory / 'events.jsonl', {
            'event': 'system_error', 'at': now(), 'stage': state.get('stage'),
            'type': type(exc).__name__, 'error': str(exc),
            'traceback': traceback.format_exc(), 'dependent_work_stopped': True,
            'stopped_for_elapsed_time': False,
        })
        state.setdefault('notices', []).append({'event': 'system_error', 'at': now(),
                                               'stage': state.get('stage'), 'error': str(exc)})
    finally:
        update_status(directory, state, config, gate)
        evidence = [
            'attempts.jsonl', 'reuse.jsonl', 'events.jsonl', 'summary.json',
            'incomplete.json', 'corrected-rule.json', 'corrected-length-results.jsonl',
            'natural-candidates.json', 'natural-rule.json', 'confirmation-results.jsonl',
            'final-summary.json', 'pc-analysis/MANIFEST.json',
        ]
        write_json(directory / 'delivery.json', {
            'protocol': 'ape-plan-exec/v1', 'role': 'EXECUTOR',
            'task_id': 'FOLLOWUP2604', 'status': state['state'], 'at': now(),
            'authorization_ref': config.get('authorization_ref'),
            'evidence': [name for name in evidence if (directory / name).exists()],
            'completed_stages': state.get('completed_stages', []),
            'blocked_stage': state.get('blocked_stage'),
            'blocked_reason': state.get('blocked_reason'),
            'requires_PLANNER_review': True, 'self_acceptance': False,
            'git_commit_or_push': False,
        })
        write_json(directory / 'controller-exit.json', {'at': now(), 'pid': os.getpid(),
            'state': state['state'], 'exit_code': 0 if state['state'] == 'SUBMITTED' else 1,
            'completed_stages': state['completed_stages']})
        os.close(lock_fd)
    return 0 if state['state'] == 'SUBMITTED' else 1


def _new_campaign(config, gate=None):
    campaign = datetime.now(timezone.utc).strftime('followup2604-%Y%m%dT%H%M%S')
    directory = inside(BASE / campaign)
    directory.mkdir(parents=True, exist_ok=False)
    write_json(directory / 'config.json', config)
    bound, gate = snapshot(directory, config)
    epoch = time.time()
    write_json(directory / 'sampling.json', {
        'corrected_validation_job_file': config['corrected_validation_jobs'],
        'corrected_validation_new_jobs': 462,
        'corrected_validation_historical_reuse': 377,
        'natural_manifest': f'{config["natural_data"]}/frozen.json',
        'natural_orders': read_json(f'{bound["natural_data"]}/frozen.json')['orders'] if gate['C_ready'] else None,
        'seed': 42, 'score_or_answer_used_for_sampling': False,
    })
    state = {
        'campaign': campaign, 'state': 'RUNNING', 'stage': STAGES[0],
        'started_at': now(), 'started_epoch': epoch, 'completed_stages': [],
        'no_wall_clock_limit': True,
        'elapsed_time_controls_execution': False, 'eta_controls_sampling': False,
        'resume_count': 0,
    }
    write_json(directory / 'state.json', state)
    update_status(directory, state, bound, gate)
    return campaign, directory


def launch(config_path=None, campaign=None):
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    lock = LOCK.open('a+')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close()
        active = read_json(ACTIVE) if ACTIVE.exists() else {}
        print(json.dumps({**active, 'already_running': True, 'liveness_evidence': 'single-instance kernel lock is held'}, ensure_ascii=False))
        return
    if campaign is None:
        if ACTIVE.exists():
            campaign = read_json(ACTIVE)['campaign']
        else:
            # One-time adoption of pre-pointer launches reads only tiny task
            # records. Ordinary status queries never scan run directories.
            existing = sorted(path.parent.name for path in BASE.glob('followup2604-*/state.json'))
            if len(existing) > 1:
                lock.close()
                raise ValueError(f'multiple recorded campaigns; choose --campaign to resume: {existing}')
            campaign = existing[0] if existing else None
    if campaign:
        if Path(campaign).name != campaign:
            lock.close()
            raise ValueError('campaign ID required')
        directory = inside(BASE / campaign)
        state = read_json(directory / 'state.json')
        if state['state'] == 'SUBMITTED':
            lock.close()
            print(json.dumps({'campaign': campaign, 'state': 'SUBMITTED', 'new_campaign_created': False}))
            return
        requested = directory / 'requested-config.json'
        config = read_json(config_path) if config_path else read_json(requested if requested.exists() else directory / 'config.json')
        _, gate = snapshot(directory, config, resume=True, register_inputs=bool(config_path))
        state['resume_count'] = int(state.get('resume_count', 0)) + 1
        state['last_resumed_at'] = now()
        write_json(directory / 'state.json', state)
        append_json(directory / 'events.jsonl', {'event': 'campaign_resumed', 'at': now(),
            'resume_count': state['resume_count'], 'successful_answers_repeated': False})
    else:
        if not config_path:
            lock.close()
            raise ValueError('--config is required for start')
        config = read_json(config_path)
        campaign, directory = _new_campaign(config)
    command = [PYTHON, '-B', '-u', '-m', 'main80.followup_campaign', '_control',
               '--campaign', campaign, '--lock-fd', str(lock.fileno())]
    with (directory / 'controller.log').open('ab') as log:
        process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True, pass_fds=(lock.fileno(),))
    write_json(directory / 'launcher.json', {
        'controller_pid': process.pid, 'cwd': str(ROOT), 'command': command,
        'at': now(), 'elapsed_time_control': False, 'timeout_kill': False,
    })
    write_json(ACTIVE, {'campaign': campaign, 'controller_pid': process.pid, 'at': now()})
    lock.close()
    print(json.dumps({
        'campaign': campaign, 'controller_pid': process.pid, 'directory': str(directory),
        'status_command': f'bash scripts/run_followup_campaign.sh status --campaign {campaign}',
        'resume_command': f'bash scripts/run_followup_campaign.sh resume --campaign {campaign}',
        'observation_command': (f'bash scripts/with_env.sh {PYTHON} -B -u scripts/observe_campaign.py '
                                f'--campaign {campaign} --seconds 60'),
        'no_experiment_wall_clock_limit': True,
    }, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('check', 'start', 'resume', 'status', '_control'))
    parser.add_argument('--config')
    parser.add_argument('--campaign')
    parser.add_argument('--lock-fd', type=int)
    args = parser.parse_args()
    if args.action == 'check':
        if not args.config:
            parser.error('--config required')
        config = read_json(args.config)
        gate = validate(config)
        print(json.dumps({
            'recorded_task_status': config.get('task_status'), 'gate': gate,
            'new_answer_upper_bound': 2604, 'deadline_or_timeout_fields': [],
            'worker_or_browser_started': False,
        }, ensure_ascii=False, indent=2))
    elif args.action == 'start':
        launch(args.config)
    elif args.action == 'resume':
        if not args.campaign:
            parser.error('--campaign required')
        launch(args.config, args.campaign)
    elif args.action == 'status':
        if not args.campaign or Path(args.campaign).name != args.campaign:
            parser.error('valid --campaign required')
        from .monitor import current_status
        print(json.dumps(current_status(inside(BASE / args.campaign)), ensure_ascii=False, indent=2))
    else:
        raise SystemExit(control(inside(BASE / args.campaign), args.lock_fd))


if __name__ == '__main__':
    main()
