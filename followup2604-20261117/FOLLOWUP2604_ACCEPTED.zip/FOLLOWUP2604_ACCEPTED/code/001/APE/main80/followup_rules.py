"""Deterministic job plans, reuse checks, and rule selection for FOLLOWUP2604."""
from collections import Counter, defaultdict
from itertools import product
from statistics import mean

from .common import identity, inside, read_json, read_records
from .jobs import JobFactory
from .metrics import score
from .rules import COUNTS, DEFAULT, PARAMS, choose, freeze_rule, tie_key


CORRECTED_RULE_VERSION = 'corrected-nine-cell-v1'
NATURAL_RULE_VERSION = 'natural-chunk-v2'
MAIN80_RULE_VERSION = 'main80-nine-cell-v1'
NATURAL_METHODS = (
    'sequential', 'pcw', 'ape_default', 'ape_main80_fixed',
    'ape_main80_dynamic', 'ape_natural_fixed', 'ape_natural_dynamic',
)


def jsonl(path):
    rows, malformed = read_records(path)
    if malformed:
        raise ValueError(f'malformed JSONL records in {path}: {malformed}')
    return rows


def _row_lookup(directory, table):
    rows = read_json(f'{directory}/{table}.json')
    return rows, {(row['sample_id'], int(row.get('L', row.get('_length')))): (index, row)
                  for index, row in enumerate(rows)}


def _generation_identity(row):
    document = row.get('document_tokens')
    if document is None:
        document = row.get('document')
    return {
        'sample_id': row['sample_id'], 'dataset': row['dataset'],
        'prefix': row['prefix'], 'document': document, 'suffix': row['suffix'],
        'max_new_tokens': row['max_new_tokens'],
    }


def _success(record, key, row=None):
    if record.get('status') != 'success' or identity(record.get('key')) != identity(key):
        raise ValueError(f'record is not the exact successful requested key: {key}')
    if not isinstance(record.get('answer'), str) or not record['answer'].strip():
        raise ValueError(f'successful record has an empty answer: {key}')
    if not isinstance(record.get('output_token_ids'), list) or not record['output_token_ids']:
        raise ValueError(f'successful record lacks generated token IDs: {key}')
    if row is not None:
        expected = score(row['dataset'], record['answer'], row['answers'])
        if abs(float(record['score']) - expected) > 1e-12:
            raise ValueError(f'official score mismatch: {key}')
    return record


def corrected_validation_partition(config):
    """Validate that 462 new jobs and 377 historical rows exactly form A."""
    factory = JobFactory(config['corrected_data'], tables=('development',))
    candidates = read_json(config['corrected_candidates'])
    expected = factory.make('validation', factory.initial_limits(), candidates)
    jobs = jsonl(config['corrected_validation_jobs'])
    reuse = jsonl(config['corrected_validation_reuse'])
    expected_keys = {identity(job['key']) for job in expected}
    job_keys = {identity(job['key']) for job in jobs}
    reuse_keys = {identity(item['key']) for item in reuse}
    if (len(expected), len(jobs), len(reuse)) != (839, 462, 377):
        raise ValueError('corrected validation count must be 839 = 462 new + 377 reused')
    if len(job_keys) != len(jobs) or len(reuse_keys) != len(reuse):
        raise ValueError('duplicate corrected validation job/reuse key')
    if job_keys & reuse_keys or job_keys | reuse_keys != expected_keys:
        raise ValueError('corrected validation jobs and reuse do not exactly partition the frozen validation')
    return expected, jobs, reuse


def validate_corrected_reuse_sources(config):
    """Recheck all 377 reuse claims before any FOLLOWUP2604 GPU launch."""
    _, _, reuse_specs = corrected_validation_partition(config)
    _, corrected_lookup = _row_lookup(config['corrected_data'], 'development')
    _, old_lookup = _row_lookup(config['historical_data'], 'development')
    old_attempts = jsonl(config['historical_attempts'])
    checked = []
    for spec in reuse_specs:
        line = int(spec['attempts_line'])
        if not 1 <= line <= len(old_attempts):
            raise ValueError('historical corrected-validation reuse line is outside its source ledger')
        source = old_attempts[line - 1]
        key = spec['key']
        location = (key['sample_id'], int(key['L']))
        if location not in corrected_lookup or location not in old_lookup:
            raise ValueError(f'reuse input row is missing: {location}')
        new_row = corrected_lookup[location][1]
        old_row = old_lookup[location][1]
        if _generation_identity(new_row) != _generation_identity(old_row):
            raise ValueError(f'non-identical validation input marked reusable: {location}')
        _success(source, key, new_row)
        checked.append((line, identity(key)))
    if len(checked) != 377 or len(set(checked)) != 377:
        raise ValueError('corrected validation reuse source review is incomplete or duplicated')
    return {'checked': 377, 'source_ledger': config['historical_attempts'],
            'generation_repeated': False}


def corrected_validation_outcomes(directory, config):
    expected, jobs, reuse_specs = corrected_validation_partition(config)
    attempts = jsonl(inside(directory) / 'attempts.jsonl')
    fresh = {identity(record['key']): record for record in attempts
             if record.get('key', {}).get('stage') == 'validation'}
    if len(fresh) != len(jobs):
        raise ValueError(f'corrected validation has {len(fresh)}/{len(jobs)} fresh unique records')
    corrected_rows, corrected_lookup = _row_lookup(config['corrected_data'], 'development')
    _, old_lookup = _row_lookup(config['historical_data'], 'development')
    old_attempts = jsonl(config['historical_attempts'])
    reused = {}
    reuse_ledger = []
    for spec in reuse_specs:
        line = int(spec['attempts_line'])
        if not 1 <= line <= len(old_attempts):
            raise ValueError('historical corrected-validation reuse line is outside its source ledger')
        source = old_attempts[line - 1]
        key = spec['key']
        _success(source, key)
        location = (key['sample_id'], int(key['L']))
        if location not in corrected_lookup or location not in old_lookup:
            raise ValueError(f'reuse input row is missing: {location}')
        new_row = corrected_lookup[location][1]
        old_row = old_lookup[location][1]
        if _generation_identity(new_row) != _generation_identity(old_row):
            raise ValueError(f'non-identical validation input marked reusable: {location}')
        _success(source, key, new_row)
        normalized = dict(source, logical_labels=spec['logical_labels'], historical_reuse=True,
                          reuse_basis=spec['reason'], source_attempts_line=line,
                          reference_answers=new_row['answers'])
        reused[identity(key)] = normalized
        reuse_ledger.append({
            'phase': 'corrected_validation', 'key': key,
            'logical_labels': spec['logical_labels'],
            'source_ledger': config['historical_attempts'], 'source_line': line,
            'basis': ('complete generation input, model, BF16, batch=1, greedy decoding, seed, '
                      'token cap, method, N, and T/S are identical'),
            'answer_reused': True, 'generation_repeated': False,
        })
    outcomes = []
    for job in expected:
        key_string = identity(job['key'])
        if key_string in fresh:
            row = corrected_rows[job['index']]
            outcomes.append(_success(fresh[key_string], job['key'], row))
        elif key_string in reused:
            outcomes.append(reused[key_string])
        else:
            raise ValueError(f'missing corrected validation outcome: {job["key"]}')
    if len(outcomes) != 839:
        raise AssertionError('corrected validation merge count changed')
    return outcomes, reuse_ledger


def corrected_rule(outcomes, candidates):
    selected = freeze_rule(outcomes, candidates)
    return {
        **selected, 'version_id': CORRECTED_RULE_VERSION, 'status': 'FROZEN',
        'rule_family': 'corrected_MAIN80_nine_cell',
        'source': {'new_answers': 462, 'historical_identical_input_reuse': 377,
                   'validation_outcomes': 839},
        'frozen_before': ['corrected_length_transfer'],
        'must_not_be_used_as': ['main80-nine-cell-v1', NATURAL_RULE_VERSION],
    }


def corrected_length_plan(config, rule):
    """Generate the exact B jobs after the corrected rule is frozen."""
    corrected_rows, corrected_lookup = _row_lookup(config['corrected_data'], 'development')
    old_rows, old_lookup = _row_lookup(config['historical_data'], 'development')
    manifest = read_json(f'{config["corrected_data"]}/frozen.json')
    selected = set(manifest['orders']['validation'][:10])
    old_attempts = jsonl(config['historical_attempts'])
    historical = {}
    for line, record in enumerate(old_attempts, 1):
        key = record.get('key', {})
        if record.get('status') == 'success' and key.get('stage') == 'length_check':
            signature = (key.get('sample_id'), int(key.get('L')), int(key.get('N')),
                         record.get('method'))
            if signature in historical:
                raise ValueError(f'duplicate historical length-check success: {signature}')
            historical[signature] = (line, record)
    jobs, reused, desired = [], [], []
    for index, row in enumerate(corrected_rows):
        if row['sample_id'] not in selected or int(row['L']) not in (6144, 12288):
            continue
        location = (row['sample_id'], int(row['L']))
        old_row = old_lookup.get(location, (None, None))[1]
        input_identical = old_row is not None and _generation_identity(row) == _generation_identity(old_row)
        for engine_method, logical_method in (('ape_fixed', 'ape_corrected_fixed'),
                                              ('ape_dynamic', 'ape_corrected_dynamic')):
            for count in COUNTS:
                param = tuple(rule['fixed']) if engine_method == 'ape_fixed' else choose(rule, row['L'], count)
                key = {
                    'stage': 'corrected_length_transfer', 'sample_id': row['sample_id'],
                    'method': logical_method, 'L': row['L'], 'N': count,
                    'position': row.get('position'), 'parameters': list(param),
                    'cache': 'cold', 'rule_version': CORRECTED_RULE_VERSION,
                }
                job = {
                    'key': key, 'table': 'development', 'index': index,
                    'method': logical_method, 'engine_method': engine_method,
                    'param': list(param), 'N': count, 'cache': 'cold',
                    'logical_labels': [logical_method], 'max_new_tokens': row['max_new_tokens'],
                }
                desired.append(job)
                source = historical.get((row['sample_id'], int(row['L']), count, engine_method))
                if input_identical and source is not None and (source[1].get('T'), source[1].get('S')) == param:
                    line, record = source
                    _success(record, record['key'], row)
                    reused.append({
                        'phase': 'corrected_length_transfer', 'key': key,
                        'logical_labels': [logical_method], 'source_ledger': config['historical_attempts'],
                        'source_line': line, 'source_key': record['key'],
                        'source_engine_method': engine_method, 'T': param[0], 'S': param[1],
                        'answer': record['answer'], 'output_token_ids': record['output_token_ids'],
                        'score': record['score'],
                        'dataset': row['dataset'], 'sample_id': row['sample_id'],
                        'L': row['L'], 'N': count, 'reference_answers': row['answers'],
                        'basis': ('complete corrected generation input equals historical input and model, BF16, '
                                  'batch=1, greedy decoding, seed, token cap, underlying method, N, and actual T/S match'),
                        'answer_reused': True, 'generation_repeated': False,
                    })
                else:
                    reasons = []
                    if not input_identical:
                        reasons.append('corrected_generation_input_changed')
                    if source is None:
                        reasons.append('no_historical_success_for_method_L_N')
                    elif (source[1].get('T'), source[1].get('S')) != param:
                        reasons.append('frozen_corrected_parameter_changed')
                    jobs.append({**job, 'reason': reasons})
    if len(desired) != 120 or not 24 <= len(jobs) <= 120 or len(jobs) + len(reused) != 120:
        raise ValueError(f'corrected length plan violates reviewed 24-120 bound: new={len(jobs)}, reused={len(reused)}')
    keys = [identity(job['key']) for job in desired]
    if len(keys) != len(set(keys)):
        raise ValueError('duplicate corrected length logical key')
    return {
        'protocol': 'ape-followup-corrected-length-plan-v1',
        'rule_version': CORRECTED_RULE_VERSION, 'desired_outcomes': 120,
        'new_jobs': len(jobs), 'historical_reuse': len(reused),
        'jobs': jobs, 'reuse': reused,
    }


def natural_rows(config):
    rows = read_json(f'{config["natural_data"]}/natural.json')
    return rows, {row['sample_id']: (index, row) for index, row in enumerate(rows)}


def natural_exploration_jobs(config):
    rows, _ = natural_rows(config)
    jobs = []
    for index, row in enumerate(rows):
        if row['split'] != 'explore':
            continue
        for param in PARAMS:
            key = {
                'stage': 'natural_exploration', 'sample_id': row['sample_id'],
                'method': 'ape_natural_grid', 'L': row['L'], 'N': row['natural_N'],
                'position': None, 'parameters': list(param), 'cache': 'search',
                'data_version': NATURAL_RULE_VERSION,
            }
            jobs.append({'key': key, 'table': 'natural', 'index': index,
                         'method': 'ape_natural_grid', 'engine_method': 'ape_fixed',
                         'param': list(param), 'N': None, 'cache': 'search',
                         'logical_labels': ['grid_search'], 'max_new_tokens': row['max_new_tokens']})
    if len(jobs) != 864 or len({identity(job['key']) for job in jobs}) != 864:
        raise ValueError('natural exploration must be 54 questions x 16 parameters')
    return jobs


def _global_weighted(records, param):
    chosen = [record for record in records if (record['T'], record['S']) == tuple(param)]
    dataset_scores = {}
    for dataset in ('qasper', 'hotpotqa', 'musique'):
        data = [record for record in chosen if record['dataset'] == dataset]
        if dataset == 'qasper':
            strata = []
            for count in (1, 2, 3):
                values = [record['score'] for record in data if record['N'] == count]
                if not values:
                    raise ValueError(f'missing Qasper N{count} weighted-selection stratum')
                strata.append(mean(values))
            dataset_scores[dataset] = mean(strata)
        else:
            values = [record['score'] for record in data if record['N'] == 1]
            if not values:
                raise ValueError(f'missing {dataset} N1 weighted-selection stratum')
            dataset_scores[dataset] = mean(values)
    return mean(dataset_scores.values())


def _conditional_weighted(records, param, count):
    chosen = [record for record in records
              if (record['T'], record['S']) == tuple(param) and record['N'] == count]
    datasets = ('qasper', 'hotpotqa', 'musique') if count == 1 else ('qasper',)
    values = []
    for dataset in datasets:
        cell = [record['score'] for record in chosen if record['dataset'] == dataset]
        if not cell:
            raise ValueError(f'missing conditional selection stratum {dataset}/N{count}')
        values.append(mean(cell))
    return mean(values)


def _paired(records, jobs):
    by_key = {identity(record['key']): record for record in records
              if record.get('status') == 'success'}
    if len(by_key) != len(jobs) or set(by_key) != {identity(job['key']) for job in jobs}:
        raise ValueError('natural stage records are incomplete or unpaired')
    return [by_key[identity(job['key'])] for job in jobs]


def select_natural_candidates(records, jobs):
    records = _paired(records, jobs)
    if any(record['split'] != 'explore' for record in records):
        raise ValueError('natural candidates may use exploration only')
    identities = {
        param: sorted((record['dataset'], record['sample_id'], record['N']) for record in records
                      if (record['T'], record['S']) == param)
        for param in PARAMS
    }
    if not identities[PARAMS[0]] or any(value != identities[PARAMS[0]] for value in identities.values()):
        raise ValueError('natural exploration parameter grid is not completely paired')
    global_scores = {param: _global_weighted(records, param) for param in PARAMS}
    conditional_scores = {
        count: {param: _conditional_weighted(records, param, count) for param in PARAMS}
        for count in (1, 2, 3)
    }
    global_best = min(PARAMS, key=lambda param: (-global_scores[param], tie_key(param)))
    by_n = {count: min(PARAMS, key=lambda param: (-conditional_scores[count][param], tie_key(param)))
            for count in (1, 2, 3)}
    name = lambda param: f'{param[0]}/{param[1]}'
    return {
        'protocol': 'ape-followup-natural-candidates-v2', 'status': 'SELECTED_FOR_VALIDATION',
        'data_version': NATURAL_RULE_VERSION, 'global': list(global_best),
        'by_N': {str(count): list(param) for count, param in by_n.items()},
        'weighted_scores': {
            'global': {name(param): global_scores[param] for param in PARAMS},
            'by_N': {str(count): {name(param): scores[param] for param in PARAMS}
                     for count, scores in conditional_scores.items()},
        },
        'weights': 'dataset-equal globally; Qasper N-equal within dataset; N1 dataset-equal; N2/N3 Qasper-only',
        'interpretation_boundary': 'multi-block candidate evidence is Qasper-only; cross-dataset differences are not block-count effects',
        'source': {'questions': 54, 'answers': 864, 'split': 'explore'},
    }


def natural_validation_jobs(config, candidates):
    rows, _ = natural_rows(config)
    jobs = []
    for index, row in enumerate(rows):
        if row['split'] != 'validation':
            continue
        choices = defaultdict(list)
        choices[DEFAULT].append('default')
        choices[tuple(candidates['global'])].append('global_candidate')
        choices[tuple(candidates['by_N'][str(row['natural_N'])])].append(
            f'N{row["natural_N"]}_conditional_candidate')
        for param, labels in choices.items():
            key = {
                'stage': 'natural_validation', 'sample_id': row['sample_id'],
                'method': 'ape_natural_validation', 'L': row['L'], 'N': row['natural_N'],
                'position': None, 'parameters': list(param), 'cache': 'search',
                'data_version': NATURAL_RULE_VERSION,
            }
            jobs.append({'key': key, 'table': 'natural', 'index': index,
                         'method': 'ape_natural_validation', 'engine_method': 'ape_fixed',
                         'param': list(param), 'N': None, 'cache': 'search',
                         'logical_labels': labels, 'max_new_tokens': row['max_new_tokens']})
    if not 36 <= len(jobs) <= 108 or len({identity(job['key']) for job in jobs}) != len(jobs):
        raise ValueError('natural validation must contain 36-108 deduplicated requests')
    return jobs


def freeze_natural_rule(records, jobs, candidates):
    records = _paired(records, jobs)
    if any(record['split'] != 'validation' for record in records):
        raise ValueError('natural rule may use validation only')
    fixed_options = {DEFAULT, tuple(candidates['global'])}
    fixed_scores = {param: _global_weighted(records, param) for param in fixed_options}
    fixed = min(fixed_options, key=lambda param: (-fixed_scores[param], tie_key(param)))
    selected, comparisons = {}, {}
    for count in (1, 2, 3):
        candidate = tuple(candidates['by_N'][str(count)])
        candidate_score = _conditional_weighted(records, candidate, count)
        fixed_score = _conditional_weighted(records, fixed, count)
        chosen = candidate if candidate_score > fixed_score else fixed
        selected[str(count)] = list(chosen)
        comparisons[str(count)] = {
            'candidate': list(candidate), 'candidate_score': candidate_score,
            'fixed': list(fixed), 'fixed_score': fixed_score,
            'selected': list(chosen), 'strict_improvement_required': True,
            'decision': 'candidate' if chosen == candidate and candidate_score > fixed_score else 'fixed_fallback',
        }
    return {
        'protocol': 'ape-followup-natural-rule-v2', 'version_id': NATURAL_RULE_VERSION,
        'status': 'FROZEN', 'rule_family': 'natural_chunks_actual_N',
        'fixed': list(fixed), 'by_N': selected,
        'fixed_validation_scores': {f'{param[0]}/{param[1]}': value
                                    for param, value in fixed_scores.items()},
        'conditional_validation': comparisons,
        'mapping': 'exact actual natural N=1/2/3; values above 3 clamp to N3 only as a defensive boundary',
        'weights': 'dataset-equal globally; Qasper N-equal; N1 dataset-equal; N2/N3 Qasper-only',
        'source': {'questions': 36, 'physical_answers': len(jobs), 'split': 'validation'},
        'frozen_before': ['independent_confirmation'],
        'must_not_be_used_as': [MAIN80_RULE_VERSION, CORRECTED_RULE_VERSION],
        'interpretation_boundary': 'multi-block validation and conclusions are Qasper-only; cross-dataset differences are not block-count effects',
    }


def confirmation_jobs(config, natural_rule):
    rows, _ = natural_rows(config)
    old_rule = read_json(config['main80_rule'])
    jobs = []
    for index, row in enumerate(rows):
        if row['split'] != 'confirmation':
            continue
        common = {'table': 'natural', 'index': index, 'N': None, 'cache': 'cold',
                  'max_new_tokens': row['max_new_tokens']}
        for method in ('sequential', 'pcw'):
            key = {'stage': 'independent_confirmation', 'sample_id': row['sample_id'],
                   'method': method, 'L': row['L'], 'N': row['natural_N'],
                   'position': None, 'parameters': None, 'cache': 'cold',
                   'rule_version': None, 'data_version': NATURAL_RULE_VERSION}
            jobs.append({**common, 'key': key, 'method': method, 'engine_method': method,
                         'param': None, 'logical_labels': [method]})
        logical_params = (
            ('ape_default', DEFAULT),
            ('ape_main80_fixed', tuple(old_rule['fixed'])),
            ('ape_main80_dynamic', choose(old_rule, row['L'], row['natural_N'])),
            ('ape_natural_fixed', tuple(natural_rule['fixed'])),
            ('ape_natural_dynamic', choose(natural_rule, row['L'], row['natural_N'])),
        )
        choices = defaultdict(list)
        versions = defaultdict(list)
        for label, param in logical_params:
            choices[tuple(param)].append(label)
            if label.startswith('ape_main80_'):
                versions[tuple(param)].append(MAIN80_RULE_VERSION)
            elif label.startswith('ape_natural_'):
                versions[tuple(param)].append(NATURAL_RULE_VERSION)
            else:
                versions[tuple(param)].append('ape-default-0.9/0.9')
        for param, labels in choices.items():
            key = {'stage': 'independent_confirmation', 'sample_id': row['sample_id'],
                   'method': 'ape_parameterized_confirmation', 'L': row['L'],
                   'N': row['natural_N'], 'position': None, 'parameters': list(param),
                   'cache': 'cold', 'rule_versions': versions[param],
                   'data_version': NATURAL_RULE_VERSION}
            jobs.append({**common, 'key': key, 'method': 'ape_parameterized_confirmation',
                         'engine_method': 'ape_fixed', 'param': list(param),
                         'logical_labels': labels, 'logical_rule_versions': versions[param]})
    confirmation_rows = [row for row in rows if row['split'] == 'confirmation']
    if len(confirmation_rows) != 150 or not 450 <= len(jobs) <= 1050:
        raise ValueError(f'independent confirmation physical request count is invalid: {len(jobs)}')
    if len({identity(job['key']) for job in jobs}) != len(jobs):
        raise ValueError('duplicate independent confirmation physical job')
    labels = Counter(label for job in jobs for label in job['logical_labels'])
    if labels != Counter({method: 150 for method in NATURAL_METHODS}):
        raise ValueError(f'independent confirmation does not preserve seven logical methods: {labels}')
    return jobs


def expand_confirmation(records, jobs):
    physical = _paired(records, jobs)
    by_key = {identity(record['key']): record for record in physical}
    expanded = []
    for job in jobs:
        record = by_key[identity(job['key'])]
        for label in job['logical_labels']:
            expanded.append({
                'sample_id': record['sample_id'], 'dataset': record['dataset'],
                'split': 'confirmation', 'natural_N': record['N'], 'L': record['L'],
                'method': label, 'answer': record['answer'], 'score': record['score'],
                'reference_answers': record['reference_answers'],
                'source_attempt_key': record['key'], 'source_attempt': record['attempt'],
                'output_token_ids': record['output_token_ids'],
                'physical_generation_shared_by': job['logical_labels'],
                'parameter_reuse': len(job['logical_labels']) > 1,
                'reuse_basis': ('same natural input and exactly the same resolved APE T/S; generation is run once '
                                'and every applicable versioned logical method label is retained')
                               if len(job['logical_labels']) > 1 else None,
                'T': record.get('T'), 'S': record.get('S'),
                'total_seconds': record.get('total_seconds'),
            })
    if len(expanded) != 1050:
        raise ValueError('expanded confirmation must contain 150 x seven logical methods')
    return expanded


def confirmation_summary(expanded):
    summary = {}
    for method in NATURAL_METHODS:
        method_rows = [row for row in expanded if row['method'] == method]
        datasets = {}
        for dataset in ('qasper', 'hotpotqa', 'musique'):
            values = [row['score'] for row in method_rows if row['dataset'] == dataset]
            if not values:
                raise ValueError(f'confirmation summary missing {method}/{dataset}')
            datasets[dataset] = mean(values)
        qasper_n = {}
        for count in (1, 2, 3):
            values = [row['score'] for row in method_rows
                      if row['dataset'] == 'qasper' and row['natural_N'] == count]
            if not values:
                raise ValueError(f'confirmation summary missing {method}/qasper/N{count}')
            qasper_n[f'N{count}'] = mean(values)
        summary[method] = {
            'dataset_means': datasets,
            'primary_equal_dataset_mean': mean(datasets.values()),
            'qasper_N_means': qasper_n,
            'qasper_equal_N_mean': mean(qasper_n.values()),
        }
    return {
        'methods': summary,
        'primary_weight': 'equal mean of Qasper, HotpotQA, and MuSiQue dataset means',
        'qasper_weight': 'N1/N2/N3 reported separately and equally weighted',
        'interpretation_boundary': 'multi-block comparisons are Qasper-only; cross-dataset differences are not block-count effects',
    }
