# FOLLOWUP2604 PC analysis

Read confirmation-results.csv or JSONL using Python standard libraries. Seven logical methods share 150 independent questions; exact APE parameters are generated once. The primary metric is the equal mean of three dataset F1 means. Qasper N1/N2/N3 are reported separately; multi-block evidence is Qasper-only. Candidate selection uses exploration and validation only.

Full input/code copies and per-worker commands remain in the campaign snapshot and workers directories; input-versions.json and code-versions.json list their exact paths. All raw attempts and reuse reasons are included. Status is SUBMITTED pending PLANNER acceptance.
