# FOLLOWUP2604 PC 分析交接

本包为 CPU 验收补充包；原始提交保存在 original-package/，服务器原始结果未改写。

入口：review/confirmation-means.csv、review/qasper-N-means.csv、review/confirmation-paired.csv；逐题答案/参考在 server/confirmation-results.jsonl，资料组和连通组件在 samples.json，实际生成和逻辑标签映射在 logical-provenance.jsonl。inputs/ 保存实际冻结输入、权重与旧规则，code/ 保存 worker 使用的版本，workers/ 保存实际 bundle 和日志，provenance/ 保存394条历史来源回答及候选重建所需探索记录。PORTABLE-PATHS.json 将原绝对路径映射到本包内文件；不得执行历史脚本。

主要比较：ape_natural_dynamic − ape_natural_fixed。主指标为三数据集 F1 均值的等权宏平均；确认集 Qasper 内按题平均，再另报 N1/2/3 和 N 等权均值。选参权重见 inputs/datasets/frozen-followup-v2/scoring-weights.json，不能用确认集重新选参。

PC 后续建议：固定种子20261116，5,000次按资料组配对 Bootstrap。在各数据集内重采样支撑资料连通组件（samples.json 的 support_component），每次对全部方法使用相同抽样组件；同一组件的全部题一起纳入，保留题数权重，先重算数据集内题均值，再对三个数据集等权合并。Qasper 分层报告时使用相同的成对组件抽样，缺失分层的重采样须显式记录并重抽；报告有效次数、组件数和2.5%/97.5%百分位区间。如数据集只有一个组件，则该数据集的组间不确定性不可识别，区间必须标注为仅条件于该冻结组件，不能改用逐题独立抽样来掩盖这一限制。长度迁移按冻结支撑组同样配对，不能把6种L/N当独立题。

区间跨零不解释为等效；局部 N2 改善不能代替总体结论。多块结论仅限 Qasper。复用标签没有独立耗时；本轮没有稳定加速证据。本次不执行 Bootstrap、不上传、不提交或推送。
